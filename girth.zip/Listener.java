public interface Listener {
  public void update();
  public void initialize();
}
